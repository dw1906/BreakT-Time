import React, { Component } from "react";
import Microbreak from "./Microbreak";
import profile from '../images/profile.jpg';
import RCard from './RCard';
import Notify from './Notify';
import service from '../DataService';


class Welcome extends Component {

  getData = () => {
    let data = window.localStorage.getItem("name")
    return data;
  }
  showNotification(){
    const notification = new Notification("Hii !!",{
      body:"Sitting for a long time?? Let's have some coffee!!"
    });
  }
  
  componentDidMount (){
    console.log(Notification.permission);
    if(Notification.permission== "granted" ){
    alert("We have permission !!");
    }
    else if(Notification.permission!== "denied"){
    Notification.requestPermission().then(permission => {
        if(permission === "granted"){
            console.log(permission);
            const timer = window.setInterval(function(){
              if(Notification.permission==="granted")  
              this.showNotification();
            }, 1000);       
        }
        console.log(permission);
        });
        }
  }
   render(){
      return (
      <div >
        <div>
          <h1 style={{ marginBottom: 0, textDecoration: 'none'}}>Welcome {this.getData()} !!</h1>
          <img style={{borderRadius:"25px"}} src={profile}/>
          <Notify/>
        </div>
        <Microbreak/>
        <RCard/>
      </div>
    );
  }
}
  
export default Welcome;