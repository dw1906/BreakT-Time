import axios from 'axios';
const BREAK_TIME_URL = 'http://localhost:8080'
const API_URL = `${BREAK_TIME_URL}/welcome`
    
// /*
// This method will fetch all categories stored in database.
// params: nothing
// axios return type: List<String>
// path call: "/welcome"
// */
class DataService { 
     fetchAllCategories() 
    {
        const data = axios.get(`${API_URL}`);
        console.log(data);
        return data;
    }

    /*
    /*
    This method will fetch all sub-categories(or interest names) of given category stored in database.
    params: String category (e.g. "Music", "Exercise")
    axios return type: List<String>
    path call: "/welcome/{category}"
    */
     fetchInterestNames(category) 
    {
        const data = axios.get(`${API_URL}/${category}`)
        console.log(`Status: ${data.status}`)
        console.log(data);
        return data;
    }

    /**
    This method will fetch all sub-categories(or interest names) of given category stored in database.
    params: JSON object containing emailID and name.
    axios return type: boolean
    path call: "/"
    */
   createUser(Users) 
    {
        const data = axios.post(`${BREAK_TIME_URL}`,Users);
        //console.log(data);
        return data;
    }


    /**
    This method will delete user account and all related data.
    params: String emailID
    axios return type: boolean (e.g. true/false)
    path call: "/welcome/deleteAccount/{emailID}"
    */
     deleteUserAccount(emailID) 
    {
        const data = axios.delete(`${API_URL}/deleteAccount/${emailID}`);
        console.log(data);
        return data;
    }


    /**
    This method will snooze all notifications for a given user.
    params: String emailID
    axios return type: boolean (e.g. true/false)
    path call: "/welcome/snooze/${email}"
    */
     snooze(emailID) 
    {
        const data = axios.put(`${API_URL}/snooze/${emailID}`);
        console.log(data);
        return data;
    }


    /**
    This method will unsnooze all notifications for a given user.
    params: String emailID
    axios return type: boolean (e.g. true/false)
    path call: "/welcome/unsnooze/{email}"
    */
     unsnooze(emailID) 
    {
        const data = axios.put(`${API_URL}/unsnooze/${emailID}`);
        console.log(data);
        return data;
    }


    /**
    This method will fetch username of a given user.
    params: String emailID
    axios return type: String (e.g. "Deshna"), if username not found then returns null.
    path call: "/welcome/userName/${email}"
    */
    fetchUsername(emailID) 
    {
        const data = axios.get(`${API_URL}/userName/${emailID}`);
        console.log(data);
        return data;
    }


    /**
    This method add interest for a user in database.
    params: String emailID, String category, String subcategory
    axios return type: boolean (true/false).
    path call: "/welcome/addInterest/{email}/{category}/{subcategory}"
    */

     addInterest(emailID, category) 
    {
        let obj = {
            "emailID":emailID,
            "category":category
        }
        const data = axios.put(`${API_URL}/addInterest`,obj);
        console.log(data);
        return data;
    }


    /*
    This method ill delete sub-cateory(or interestName) for a user in database.
    params: String emailID, String category, String subcategory
    axios return type: boolean (true/false).
    path call: "/welcome/deleteInterest/{email}/{category}/{subcategory}"
    */
     deleteInterest( emailID, category,subcategory) 
    {
        const data = axios.delete(`${API_URL}/deleteInterest/${emailID}/${category}/${subcategory}`);
        console.log(data);
        return data;
    }
}
export default new DataService();