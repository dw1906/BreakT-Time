import addNotification from 'react-push-notification';
 
const Notify = () => {

    const buttonClick = () => {
        addNotification({
            title: 'Warning',
            subtitle: 'This is a subtitle',
            message: 'This is a very long message',
            theme: 'darkblue',
           //onClick: (e: Event | Notification) => void, //optional, onClick callback.
            theme: 'red', //optional, default: undefined
            duration: 3000, //optional, default: 5000,
            closeButton: 'Go away', //optional, text or html/jsx element for close text. Default: Close,
            //icon?: string, // optional, Native only. Sets an icon for the notification.
            //vibrate?: number | number[], // optional, Native only. Sets a vibration for the notification.
            silent: false 
        });
    };
 
    return (
      <div className="page">
          <button onClick={buttonClick} className="button">
           Send Notifications
          </button>
      </div>
    );
};
 
export default Notify;