import React,{Component} from 'react';
import '../css/landing.css';
import service from '../DataService';
 
class Landing extends Component{
    constructor(props){
        super(props);
        this.state= {
          email:"",
          name: ""
        };    
        }
        handleEmailChange = (event) => {
            this.setState({...this.state, email: event.target.value});
          }
        handleSubmit = (event) => {
            event.preventDefault(); 
            this.setData(this.state.email,this.state.name);
            //console.log(this.state.name);   
            let obj = {
                emailID : this.state.email,
                name : this.state.name
            };
            let status = service.createUser(obj).then(this.props.history.push('/welcome'));
            ////console.log(status);
        }  
        handleNameChange = (event) => {
            this.setState({...this.state, name: event.target.value});
          }  
        setData =(email,name) => {
            //console.log(name);
            window.localStorage.setItem("email",email)
            window.localStorage.setItem("name", name)
        }
           
        render(){
            return(  
            <div>
                <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/cover/"></link>
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />               
                <link href="../../dist/css/bootstrap.min.css" rel="stylesheet"></link>
                <div class="cover-container d-flex h-100 p-3 mx-auto flex-column">
                <header class="masthead mb-auto">
                    <div class="inner">
                    
                    </div>
                </header>

                <main role="main" class="inner cover"><br/>
                    <h1 class="cover-heading" style={{color:"#7C4242"}}>It's okay to take a break!!</h1><br/><br/>
                <div className="quote"><p class="lead">“Let’s loosen up some time and take a break to re-calibrate our life. We need no endless over-thinking, though. Let’s just connect the dots, set the scene, and steam ahead. ("On a casual day without a tie")”</p>
                    <p class="lead">  
                    </p></div>  
                </main>
                <div className="landing" >
                    <br/><br/>
                    <form onSubmit={this.handleSubmit}>
                    <input  
                        type="email"
                        name="email"
                        onChange={this.handleEmailChange}
                        placeholder="Enter Email"
                        value={this.state.email} aria-describedby="basic-addon2"
                    /><br/>
                    <input
                        type="text"
                        name="name"
                        onChange={this.handleNameChange}
                        placeholder="Enter your name"
                        value={this.state.name}
                    /><br/>
                    <input href="/welcome" type="submit" value="Get Started!!"/>
                    </form>
                </div>
                </div>
            </div>
            );
        }
    }
export default Landing; 