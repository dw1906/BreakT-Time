import React from 'react';
import { Component } from 'react';
import {Card,Button} from 'react-bootstrap';
import '../css/cards.css';
import service from '../DataService';

class RCard extends Component {
    constructor(props){
        super(props);
        this.state = {
            interests:[]
        };
        this.getInterests();
    }
    getInterests = () =>{
        return service.fetchAllCategories()
            .then(
                response => {
                    //console.log(response);
                    this.setState({ interests: response.data })
                }
            )
    } 
    getData = () => {
        let data = window.localStorage.getItem("email")
        return data;
      }
    addInterests = (event) => {
        console.log(event.target.name);
        return service.addInterest(this.getData(),event.target.name).then(alert("Hoorey!! "+ event.target.name+" Interest Added."))
    }
    renderCard = (interest,index) =>{
        return(
            <div className="col-md-4 col-sm-6 col-xs-12">
                <Card className="card" style={{backgroundColor:"white",boxShadow:"10px 10px 10px grey"}}>
                    <Card.Body> 
                        <Card.Text>{interest}</Card.Text>
                        <div style={{width:"50%",marginLeft:"25%",marginRight:"25%",backgroundColor:"#ed7966", borderRadius:"1.5em"}}>
                            <a href="#" name={interest} value="add"  style={{color:"white",backgroundColor:"#ed796"}} onClick={this.addInterests} className="btn btn-block" >Add to Interests</a>
                        </div>
                        </Card.Body>
                </Card>
            </div>
        )
    }
    render(){      
        //console.log(this.state.interests); 
        return <div style={{paddingBottom:"50px"}}>  
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="newcss.css" />
        <div className="content">
        <div className="container-fluid bg-black">
        <div>
            <h1 style={{ marginBottom: 0, fontFamily: '"times new roman"', textDecoration: 'none'}}>Select Interests!!!</h1>
            <br/> 
        </div>  
            {this.state.interests.map(this.renderCard)}'</div>'
        </div>
        </div>
    }
};
export default RCard;