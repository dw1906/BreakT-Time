import React,{Component} from 'react'
import './css/App.css';
import AppNavbar from './AppNavBar';
import AppRouter from './AppRouter';
import { Notifications } from "react-push-notification";

class App extends Component {

  render() {
      return (
      <div className="App">
          <AppNavbar />
          <Notifications/>
          <div className="container maincontainer" >
          <AppRouter />
          </div>
        <div className="footer"></div>
      </div>
    );
  }
}

export default App;
