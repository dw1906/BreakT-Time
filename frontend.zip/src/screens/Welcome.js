import React, { Component } from "react";
import Microbreak from "./Microbreak";
import Micro from "./Micro";
import profile from '../images/profile.jpg';
import RCard from './RCard';
import Card from './Card';
import Notify from './Notify';


class Welcome extends Component {
  constructor(props){
    super(props);
    this.state= {
      user:"user"
    }
  }
  
    render(){return (
      <div >
        <div>
          <h1 style={{ marginBottom: 0, textDecoration: 'none'}}>Welcome User !!</h1>
          <img style={{borderRadius:"25px"}} src={profile}/>
          <Notify/>
        </div>
        <Microbreak/>
        <RCard/>
      </div>
    );
  }
}
  
export default Welcome;