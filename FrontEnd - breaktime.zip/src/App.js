import React,{Component} from 'react'
import './css/App.css';
import AppNavbar from './AppNavBar';
import AppRouter from './AppRouter';

class App extends Component {

  render() {
      return (
        
      <div className="App">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
          <AppNavbar />
          <div className="container maincontainer" >
          <AppRouter />
          </div>
        <div className="footer"></div>
      </div>
    );
  }
}

export default App;
