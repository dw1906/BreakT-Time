import React, { Component } from 'react';
import './css/App.css';
import logo from './images/logo.jpg';
import logo1 from './images/1.jpg';
import { Container,Row,Col } from 'react-bootstrap';

class AppNavbar extends Component {
    render() {
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;700;900&family=Ubuntu:wght@300&display=swap" rel="stylesheet"></link>
        return <div className="nav">
                <Container>
                    <Row>
                    <Col> <img className="logo1" src = {logo1}></img>
                    </Col>
                    <Col> <h1 style={{color: '#FFFFFF',fontSize:40,textAlign:'left',marginTop:35, fontFamily:'Lora,serif', textDecoration: 'none'}}>BREAK-TIME</h1>
                    </Col><Col> </Col>
                    </Row>
                </Container>
              </div>
    }
}

export default AppNavbar;