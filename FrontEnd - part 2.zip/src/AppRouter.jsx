import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Welcome from './screens/Welcome';
import Landing from './screens/Landing';
import Message from './Message';
import Click from './screens/click';

class AppRouter extends Component{
  render(){
    return(
        <>
            <Router>
             <Switch>
              <Route path="/" exact component={Landing} />
              <Route path="/welcome" exact component={Welcome} />
              <Route path="/click" exact component={Click} />
             </Switch>
           </Router>
        </>
    );
  }
}

export default AppRouter;