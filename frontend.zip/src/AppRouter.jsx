import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
//import LoginComponent from './screens/LoginComponent'
//import ListCustomersComponent from './screens/ListCustomersComponent'
//import CustomerDetails from './screens/CustomerDetails'
//import AddUpdateCustomer from './screens/AddUpdateCustomer.jsx'
import Welcome from './screens/Welcome';
import Landing from './screens/Landing';
import Message from './Message';
import Click from './screens/click';

class AppRouter extends Component{
  render(){
    return(
        <>
            <Router>
             <Switch>
              <Route path="/" exact component={Welcome} />
              <Route path="/landing" exact component={Landing} />
             {/* <Route path="/message" exact component={Message} />*/}
              <Route path="/click" exact component={Click} />
            {/*   <Route path="/login" component={LoginComponent} />
               <Route path="/addCustomer" component={AddUpdateCustomer} />
               <Route path="/home" component={ListCustomersComponent} />
               <Route path="/updateCustomer/:id" component={AddUpdateCustomer} />
                <Route path="/showCustomer/:id" component={CustomerDetails} />*/}
             </Switch>
           </Router>
        </>
    );
  }
}

export default AppRouter;