import React, { useState, useEffect ,Component} from "react";

import image1 from './images/image1.png';
import firebase from './firebase';
function Message (){
    React.useEffect(()=>{
        const msg = firebase.messaging();
        msg.requestPermission().then(()=>{
            return msg.getToken();
        }).then((data)=>{
            console.warn("token",data);
        })
    });
        return(
            <div >
                <div class="push">
                <img width="50px" class="image" src={image1} alt="Push Notification" />
                </div>
          </div>
        );
}
export default Message;