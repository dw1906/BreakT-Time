import React,{Component} from 'react';
import '../css/landing.css';
import service from '../DataService';

class Landing extends Component{
    constructor(props){
        super(props);
        this.state= {
          email:""
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
      handleChange(event) {
        this.setState({email: event.target.value});
      }
    handleSubmit = (event) => {
        alert('A name was submitted: ' + this.state.email);
        event.preventDefault();    
    }    
    componentDidMount() {
        let obj = {
            emailID:this.state.email,
            name:"john"
        };
    }
        render(){
            return(    
                <div className="landing" >
                    <form  onSubmit={this.handleSubmit}>
                    <label>Email</label>
                    <input
                        type="email"
                        name="email"
                        onChange={this.handleChange}
                        placeholder="Enter Email"
                        value={this.state.email}
                    />
                    <input type="submit" value="Submit"/>
                    </form>
                </div>
            );
        }
    }
export default Landing; 