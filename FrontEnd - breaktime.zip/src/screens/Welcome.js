import React, { Component } from "react";
import Microbreak from "./Microbreak";
import profile from '../images/profile.jpg';
import RCard from './RCard';


class Welcome extends Component {
  constructor(props){
    super(props);
  }
  getData = () => {
    let data = window.localStorage.getItem("name")
    return data;
  }
  showNotification = () =>{
    const notification = new Notification("Hii !!",{
      body:"Sitting for a long time?? Let's have some coffee!!"
    });
  }
  
  componentDidMount (){
    console.log(Notification.permission);
    if(Notification.permission== "granted" ){
    //alert("We have permission !!");
    //this.showNotification();
    const timer = window.setInterval(function(){
      this.showNotification();
    }, 10000);
    }
    else if(Notification.permission!== "denied"){
    Notification.requestPermission().then(permission => {
        if(permission === "granted"){
            console.log(permission);
            const timer = window.setInterval(function(){
              this.showNotification();
            }, 100000);       
        }
        console.log(permission);
        });
        }
  }
   render(){
      return (
      <div >
        <div>
          <h1 style={{ marginBottom: 0, textDecoration: 'none'}}>Welcome {this.getData()} !!</h1>
          <img style={{borderRadius:"25px"}} src={profile}/>
        </div>
       
        <RCard/>

        <Microbreak/>
      </div>
    );
  }
}
  
export default Welcome;