import React from 'react';
import {Card,Button} from 'react-bootstrap';
import '../css/cards.css';

const RCard = () => {
    const cardInfo =[ 
        {title:"Card 1", text:"Some Text", add:"1",color:"red"},
        {title:"Card 2", text:"Some Text", add:"1",color:"blue"},
        {title:"Card 3", text:"Some Text", add:"1",color:"green"},
        {title:"Card 4", text:"Some Text", add:"1",color:"yellow"},
    ];
    const setBg = () => {
        const randomColor = Math.floor(Math.random()*16777215).toString(16);
        return ("#" + randomColor);
    }
    const renderCard = (card,index) =>{
        return(
            <div className="col-md-4 col-sm-6 col-xs-12">
                <Card className="card" style={{backgroundColor:setBg()}}>
                    <Card.Body> 
                        <Card.Title>{card.title}</Card.Title>
                        <Card.Text>{card.text}</Card.Text>
                        <div style={{backgroundColor:"white", borderRadius:"1.5em"}}>
                            <a href="" name="add" value="add" className="btn btn-block " style={{color:"black"}}>Add to Interests</a>
                        </div>
                        </Card.Body>
                </Card>
            </div>
        )
    } 
    return <div style={{paddingBottom:"50px"}}>  
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="newcss.css" />
    <div className="content">
    <div className="container-fluid bg-black">
    <div>
        <h1 style={{ marginBottom: 0, fontFamily: '"times new roman"', textDecoration: 'none'}}>Select Interests!!!</h1>
        <br/> 
    </div>  
        {cardInfo.map(renderCard)}'</div>'
    </div>
    </div>
};
export default RCard;