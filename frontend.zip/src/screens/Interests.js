import React, {Component} from 'react';     

Interest = () => {
    const cardInfo =[ 
        {title:"Card 1", text:"Some Text", add:"1"},
        {title:"Card 2", text:"Some Text", add:"1"},
        {title:"Card 3", text:"Some Text", add:"1"},
        {title:"Card 4", text:"Some Text", add:"1"},
    ];
    const renderCard = (card,index) =>{
        return(
                <Card key={index}>
                    <Card.Body>
                        <Card.Title>{card.title}</Card.Title>
                        <Card.Text>{card.text}</Card.Text>
                        <Button variant="primary">Add to Interests</Button>
                    </Card.Body>
                </Card>
        )
    } 
    return(
        <div>
            
        </div>
    );

}
export default Interest;

    
    return <div className="grid col-md-4 col-sm-6 col-xs-12"  >
        {cardInfo.map(renderCard)}
    </div>