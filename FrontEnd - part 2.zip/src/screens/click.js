import React, {Component} from 'react';
import NotifyMe from 'react-notification-timeline';

class click extends Component{ 
    
    setData =() => {
        localStorage.setItem('email',"test@gmail.com")
    }
    getData = () =>{
        let data = localStorage.getItem('email')
        //alert(data)
    }
    showNotification(){
        const notification = new Notification("Hii !!",{
          body:"Sitting for a long time?? Let's have some coffee!!"
        });
    }
    componentDidMount (){
    console.log(Notification.permission);
    if(Notification.permission== "granted" ){
    alert("We have permission !!");
    }
    else if(Notification.permission!== "denied"){
    Notification.requestPermission().then(permission => {
        if(permission === "granted"){
            console.log(permission);
            const timer = window.setInterval(function(){
                
                this.showNotification();
            }, 1000);
                 
        }
        console.log(permission);
    });
        }
    }
    showCont = () => {
        window.setInterval(function(){        
            this.showNotification();
        }, 1000);
    }
    
    render(){
        return(
            <div>
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
                <button onClick={this.setData} >
                    Hello
                </button>
                <button onClick={this.getData}>
                   Bye
                </button>
                <header class="bg-teal-800 text-white w-full shadow-lg sticky top-0 text-xl text-center p-3 shadow font-black">
                <h1>A Notifications Trigger Demo</h1>
                </header>
                <main class="max-w-md mx-auto p-4 py-16">
                <p>This is an example for the new <a class="underline" href="https://web.dev/notification-triggers/" target="_blank">Notification Trigger API</a>. Click on the Button to show a notification in 10 seconds. The code for this example is <a class="underline" target="_blank" href="https://github.com/nico-martin/notification-trigger-demo">available on GitHub</a>.</p>
                <p id="error" class="pt-8 text-red-600 text-center font-black hidden mx-auto max-w-sm"></p>
                <p class="pt-16 text-center">
                    <button id="notification-button" class="text-center bg-teal-800 hover:bg-teal-900 text-white rounded px-4 py-3">Notify in 10 seconds</button>
                    <button id="notification-cancel" class="text-center border-2 border-teal-800 hover:border-teal-900 hover:bg-teal-100 text-teal-900 rounded px-4 py-3 ml-4">cancel notifications</button>
                </p>
                </main>
                
                <div className="notification-container">
                
                </div>
            
            </div>
        );
    }
}
export default click;