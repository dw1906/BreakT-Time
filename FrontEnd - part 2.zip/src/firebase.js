import firebase from 'firebase';

var firebaseConfig = {
    apiKey: "AIzaSyC4rgZxRSceRiyJJdNmn4I5srv5C740nJ0",
    authDomain: "break-time-33ffe.firebaseapp.com",
    projectId: "break-time-33ffe",
    storageBucket: "break-time-33ffe.appspot.com",
    messagingSenderId: "467097358974",
    appId: "1:467097358974:web:3d7f77b26341d3c4a17e2f",
    measurementId: "G-Z51FB9516Z"
  };
  firebase.initializeApp(firebaseConfig);
  export default firebase;