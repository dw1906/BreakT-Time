import React, { Component } from "react";
import Microbreak from "./Microbreak";
import profile from '../images/profile.jpg';
import RCard from './RCard';
import Notify from './Notify';
import service from '../DataService';


class Welcome extends Component {

  getData = () => {
    let data = window.localStorage.getItem("name")
    return data;
  }
   render(){
      return (
      <div >
        <div>
          <h1 style={{ marginBottom: 0, textDecoration: 'none'}}>Welcome {this.getData()} !!</h1>
          <img style={{borderRadius:"25px"}} src={profile}/>
          <Notify/>
        </div>
        <Microbreak/>
        <RCard/>
      </div>
    );
  }
}
  
export default Welcome;