import React, {Component} from 'react';

class click extends Component{ 
    setData =() => {
        localStorage.setItem('email',"test@gmail.com")
    }
    getData = () =>{
        let data = localStorage.getItem('email')
        alert(data)
    }
    render(){       
        return(
            <div>
                <button onClick={this.setData} >
                    Hello
                </button>
                <button onClick={this.getData}>
                   Bye
                </button>
            </div>
        );
    }
}
export default click;