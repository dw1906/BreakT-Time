import React,{Component} from "react";
import '../css/cards.css';
import DataService from "../DataService";
class Microbreak extends Component{
    render(){
        return(
            <div style={{paddingBottom:"0px",fontFamily: "'ubuntu', sans-serif"}}>  
                <meta name="viewport" content="width=device-width, initial-scale=1" />
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
                <div className="content">
                    <div className="container-fluid bg-black">
                        <hr />
                        <div>
                            <h1 style={{ marginBottom: 0, textDecoration: 'none'}}>Quick Breaks !!</h1>
                            <br/> 
                        </div> 
                        <div>
                        </div>
                        <div className="col-md-4 col-sm-6 col-xs-12">
                        <div className="card1 panel text-center"  style={{boxShadow:"10px 10px 10px grey",borderRadius:"2em"}}>
                            <div className=" panel-body ">
                            <h4 className="p-bold">Quick meditation</h4>
                            <div style={{width:"50%",marginLeft:"25%",marginRight:"25%",textAlign:"center",backgroundColor:"#ed7966", borderRadius:"1.5em"}}>
                            <a href="#" name="add" value="add" className="btn btn-block " style={{color:"white",backgroundColor:"#ed796"}}>Add to Interests</a>
                            </div></div>
                        </div>
                        </div>
                        <div className="col-md-4 col-sm-6 col-xs-12" >
                        <div className="card1 panel panel-default text-center" style={{boxShadow:"10px 10px 10px grey",borderRadius:"2em"}}>
                            <div className="panel-body" style={{borderRadius:"2em"}}>
                            <h4 className="p-bold">Strech your arms</h4>
                            <div style={{width:"50%",marginLeft:"25%",marginRight:"25%",backgroundColor:"#ed7966", borderRadius:"1.5em"}}>
                            <a href="#" name="add" value="add" style={{color:"white",backgroundColor:"#ed796"}} className="btn btn-block ">Add to Interests</a>
                            </div></div>
                        </div>
                        </div>
                        <div className="col-md-4 col-sm-6 col-xs-12">
                        <div className="card1 panel panel-default text-center "  style={{boxShadow:"10px 10px 10px grey",borderRadius:"2em"}}>
                            <div className="panel-body">
                            <h4 className="p-bold">Close your eyes</h4>
                           <div style={{width:"50%",marginLeft:"25%",marginRight:"25%",backgroundColor:"#ed7966", borderRadius:"1.5em"}}>
                            <a href="#" name="add" value="add" style={{color:"white",backgroundColor:"#ed796"}} className="btn btn-block">Add to Interests</a>
                            </div></div>
                        </div>
                        </div>
                        <hr />  
                        <div className="col-md-4 col-sm-6 col-xs-12">
                        <div className="card1 panel panel-default text-center" style={{boxShadow:"10px 10px 10px grey",borderRadius:"2em"}}>
                            <div className="panel-body"  >
                            <h4 className="p-bold">Drink some water!!</h4>
                             <div style={{width:"50%",marginLeft:"25%",marginRight:"25%",backgroundColor:"#ed7966", borderRadius:"1.5em"}}>
                            <a href="#" name="add" value="add" style={{color:"white",backgroundColor:"#ed796"}} className="btn btn-block">Add to Interests</a>
                            </div></div>
                        </div>
                        </div>
                        <div className="col-md-4 col-sm-6 col-xs-12">
                        <div className="card1 panel panel-default text-center"  style={{boxShadow:"10px 10px 10px grey",borderRadius:"2em"}}>
                            <div className="panel-body">
                            <h4 className="p-bold">Take a Deep breath</h4>
                            <div style={{width:"50%",marginLeft:"25%",marginRight:"25%",backgroundColor:"#ed7966", borderRadius:"1.5em"}}>
                            <a href="#" name="add" value="add" style={{color:"white",backgroundColor:"#ed796"}} className="btn btn-block">Add to Interests</a>
                            </div></div>
                        </div>
                        </div>
                        <div className="col-md-4 col-sm-6 col-xs-12">
                        <div className="card1 panel panel-default text-center"style={{boxShadow:"10px 10px 10px grey",borderRadius:"2em"}}>
                            <div className="panel-body">
                            <h4 className="p-bold">Stand Up</h4>
                            <div style={{width:"50%",marginLeft:"25%",marginRight:"25%",backgroundColor:"#ed7966", borderRadius:"1.5em"}}>
                            <a href="#" name="add" value="add"  style={{color:"white",backgroundColor:"#ed796"}} className="btn btn-block" >Add to Interests</a>
                            </div></div>
                        </div>
                    </div>
                </div>
                <hr />
          </div>
        </div>
        );
    }
}
export default Microbreak;